import 'package:get/get.dart';

class NoConnectionController extends GetxController {}
