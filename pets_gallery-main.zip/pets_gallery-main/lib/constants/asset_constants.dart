class AssetConstants {
  static const imgLogo = 'assets/images/pets.jpg';
  static const imgLogin = 'assets/images/login.jpg';
  static const imgSignup = 'assets/images/signup.jpg';
  static const imgPerson = 'assets/images/person.jpg';
}
