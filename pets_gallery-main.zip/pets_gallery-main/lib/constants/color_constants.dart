import 'package:flutter/material.dart';

class ColorConstants {
  static const Color primaryColor = Color(0xFF469fef);
}
