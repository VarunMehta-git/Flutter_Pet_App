class FirebaseConstants {
  static const String usersCollection = 'users';
  static const String petsCollection = 'pets';
  static const String favouritesCollection = 'favourites';
}
