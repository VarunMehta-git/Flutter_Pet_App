class GBLatLng {
  GBLatLng({
    required this.lat,
    required this.lng,
  });
  double lat;
  double lng;
}
