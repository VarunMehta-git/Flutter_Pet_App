import 'package:flutter_test/flutter_test.dart';

import 'package:geocoder_buddy/geocoder_buddy.dart';

void main() {}
